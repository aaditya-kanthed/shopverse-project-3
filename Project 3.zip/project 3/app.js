(()=>{
'use strict';
/* ===== PRODUCT DATA (30+ Indian products) ===== */
const PRODUCTS=[
{id:1,name:"Samsung Galaxy M34 5G",brand:"Samsung",category:"electronics",price:13999,originalPrice:21999,rating:4.3,reviews:12453,image:"https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=500&h=500&fit=crop",description:"6.5\" sAMOLED FHD+, 6000mAh battery, 50MP triple camera, 6GB RAM, 128GB storage. 5G ready.",badge:"Best Seller",platforms:{flipkart:13999,amazon:14499,meesho:15299}},
{id:2,name:"boAt Rockerz 450 Headphones",brand:"boAt",category:"electronics",price:1299,originalPrice:3990,rating:4.1,reviews:89234,image:"https://images.unsplash.com/photo-1505740420928-5e560c06d30e?w=500&h=500&fit=crop",description:"40mm drivers, 15h playback, padded ear cushions, Bluetooth v5.0, aux support, lightweight design.",badge:"Top Rated",platforms:{flipkart:1299,amazon:1399,meesho:1199}},
{id:3,name:"Noise ColorFit Pro 4 Smartwatch",brand:"Noise",category:"electronics",price:2999,originalPrice:5999,rating:4.2,reviews:34521,image:"https://images.unsplash.com/photo-1546868871-af0de0ae72be?w=500&h=500&fit=crop",description:"1.72\" AMOLED display, Bluetooth calling, SpO2, heart rate, 100+ sports modes, 7-day battery.",badge:"New",platforms:{flipkart:2999,amazon:3199,meesho:3499}},
{id:4,name:"Redmi 12 5G",brand:"Xiaomi",category:"electronics",price:10999,originalPrice:17999,rating:4.0,reviews:23456,image:"https://images.unsplash.com/photo-1598327105666-5b89351aff97?w=500&h=500&fit=crop",description:"6.79\" FHD+, Snapdragon 4 Gen 2, 50MP AI dual camera, 5000mAh, 4GB+128GB.",badge:"",platforms:{flipkart:10999,amazon:11499,meesho:11999}},
{id:5,name:"JBL Flip 5 Bluetooth Speaker",brand:"JBL",category:"electronics",price:7999,originalPrice:11999,rating:4.5,reviews:15678,image:"https://images.unsplash.com/photo-1608043152269-423dbba4e7e1?w=500&h=500&fit=crop",description:"20W output, 12h playtime, IPX7 waterproof, PartyBoost, USB-C charging, bold sound.",badge:"Deal",platforms:{flipkart:7999,amazon:8499,meesho:9299}},
{id:6,name:"HP Pavilion Laptop 15",brand:"HP",category:"electronics",price:52990,originalPrice:67999,rating:4.4,reviews:5643,image:"https://images.unsplash.com/photo-1496181133206-80ce9b88a853?w=500&h=500&fit=crop",description:"12th Gen i5, 16GB RAM, 512GB SSD, 15.6\" FHD IPS, Intel Iris Xe graphics, Windows 11.",badge:"Premium",platforms:{flipkart:52990,amazon:53990,meesho:56999}},
{id:7,name:"Levi's Men Slim Fit Jeans",brand:"Levi's",category:"fashion",price:1799,originalPrice:3999,rating:4.3,reviews:28912,image:"https://images.unsplash.com/photo-1542272604-787c3835535d?w=500&h=500&fit=crop",description:"511 slim fit, premium cotton stretch denim, mid-rise, 5-pocket styling, dark indigo wash.",badge:"55% Off",platforms:{flipkart:1799,amazon:1999,meesho:1599}},
{id:8,name:"Nike Air Max 270 Shoes",brand:"Nike",category:"fashion",price:8995,originalPrice:13995,rating:4.6,reviews:8734,image:"https://images.unsplash.com/photo-1542291026-7eec264c27ff?w=500&h=500&fit=crop",description:"Max Air unit, mesh upper, foam midsole, rubber outsole, iconic 270 degree heel unit, breathable comfort.",badge:"Trending",platforms:{flipkart:8995,amazon:9295,meesho:9995}},
{id:9,name:"Puma Men's T-Shirt",brand:"Puma",category:"fashion",price:699,originalPrice:1499,rating:4.1,reviews:45231,image:"https://images.unsplash.com/photo-1521572163474-6864f9cf17ab?w=500&h=500&fit=crop",description:"100% cotton, regular fit, crew neck, Puma cat logo, soft fabric, available in 8 colors.",badge:"",platforms:{flipkart:699,amazon:749,meesho:599}},
{id:10,name:"Wildcraft Trekking Backpack 45L",brand:"Wildcraft",category:"fashion",price:2499,originalPrice:4499,rating:4.4,reviews:6723,image:"https://images.unsplash.com/photo-1553062407-98eeb64c6a62?w=500&h=500&fit=crop",description:"45L capacity, rain cover, padded back panel, multiple compartments, laptop sleeve, breathable straps.",badge:"",platforms:{flipkart:2499,amazon:2699,meesho:2899}},
{id:11,name:"Raymond Men's Formal Shirt",brand:"Raymond",category:"fashion",price:1299,originalPrice:2499,rating:4.2,reviews:12098,image:"https://images.unsplash.com/photo-1596755094514-f87e34085b2c?w=500&h=500&fit=crop",description:"Premium cotton, regular fit, full sleeves, spread collar, wrinkle-free fabric, perfect for office.",badge:"",platforms:{flipkart:1299,amazon:1399,meesho:1199}},
{id:12,name:"Women's Ethnic Kurti Set",brand:"W",category:"fashion",price:999,originalPrice:2199,rating:4.5,reviews:34567,image:"https://images.unsplash.com/photo-1583391733956-3750e0ff4e8b?w=500&h=500&fit=crop",description:"Rayon fabric, 3/4 sleeves, mandarin collar, calf length, traditional print, comfortable daily wear.",badge:"Best Seller",platforms:{flipkart:999,amazon:1099,meesho:799}},
{id:13,name:"Prestige Induction Cooktop",brand:"Prestige",category:"home",price:1899,originalPrice:3495,rating:4.3,reviews:45678,image:"https://images.unsplash.com/photo-1556909114-f6e7ad7d3136?w=500&h=500&fit=crop",description:"2000W, push button, automatic voltage regulator, anti-magnetic wall, Indian menu preset.",badge:"",platforms:{flipkart:1899,amazon:1999,meesho:2099}},
{id:14,name:"Philips Mixer Grinder 750W",brand:"Philips",category:"home",price:3299,originalPrice:5295,rating:4.4,reviews:23456,image:"https://images.unsplash.com/photo-1570222094114-d054a817e56b?w=500&h=500&fit=crop",description:"750W turbo motor, 4 jars, advanced ventilation, 3 speed + pulse, leak-proof, 5 year warranty.",badge:"Deal",platforms:{flipkart:3299,amazon:3499,meesho:3699}},
{id:15,name:"Pigeon Stainless Steel Pressure Cooker 5L",brand:"Pigeon",category:"home",price:1149,originalPrice:2195,rating:4.2,reviews:56789,image:"https://images.unsplash.com/photo-1585515320310-259814833e62?w=500&h=500&fit=crop",description:"5L capacity, induction compatible, ISI certified, gasket release, ergonomic handles, durable body.",badge:"48% Off",platforms:{flipkart:1149,amazon:1249,meesho:1099}},
{id:16,name:"Syska LED Bulb 9W (Pack of 6)",brand:"Syska",category:"home",price:499,originalPrice:999,rating:4.0,reviews:67890,image:"https://images.unsplash.com/photo-1507473885765-e6ed057ab6fe?w=500&h=500&fit=crop",description:"9W B22 base, 50000h life, 900 lumens, energy saving, instant start, cool daylight white.",badge:"",platforms:{flipkart:499,amazon:549,meesho:469}},
{id:17,name:"Bombay Dyeing Bedsheet Set",brand:"Bombay Dyeing",category:"home",price:799,originalPrice:1499,rating:4.3,reviews:34567,image:"https://images.unsplash.com/photo-1631049307264-da0ec9d70304?w=500&h=500&fit=crop",description:"Double bed, 100% cotton, 180 TC, 1 bedsheet + 2 pillow covers, floral print, machine washable.",badge:"",platforms:{flipkart:799,amazon:849,meesho:699}},
{id:18,name:"Milton Thermosteel Flask 1L",brand:"Milton",category:"home",price:699,originalPrice:1299,rating:4.5,reviews:78902,image:"https://images.unsplash.com/photo-1602143407151-7111542de6e8?w=500&h=500&fit=crop",description:"1L capacity, keeps hot 24h/cold 24h, double wall vacuum, stainless steel, leak-proof lid.",badge:"Trending",platforms:{flipkart:699,amazon:749,meesho:649}},
{id:19,name:"Lakme Absolute Skin Dew Foundation",brand:"Lakme",category:"beauty",price:699,originalPrice:1050,rating:4.1,reviews:23456,image:"https://images.unsplash.com/photo-1596462502278-27bfdc403348?w=500&h=500&fit=crop",description:"Light coverage, dewy finish, SPF 20, oil-free, 12 shades for Indian skin tones, non-comedogenic.",badge:"",platforms:{flipkart:699,amazon:749,meesho:629}},
{id:20,name:"Nivea Soft Moisturizing Cream 300ml",brand:"Nivea",category:"beauty",price:299,originalPrice:450,rating:4.4,reviews:89012,image:"https://images.unsplash.com/photo-1556228578-0d85b1a4d571?w=500&h=500&fit=crop",description:"300ml, light texture, jojoba oil + vitamin E, non-greasy, fast absorbing, all skin types.",badge:"",platforms:{flipkart:299,amazon:319,meesho:279}},
{id:21,name:"Mamaearth Vitamin C Face Serum",brand:"Mamaearth",category:"beauty",price:499,originalPrice:699,rating:4.0,reviews:45678,image:"https://images.unsplash.com/photo-1620916566398-39f1143ab7be?w=500&h=500&fit=crop",description:"30ml, natural vitamin C, turmeric extract, brightens skin, reduces dark spots, paraben-free.",badge:"Organic",platforms:{flipkart:499,amazon:499,meesho:449}},
{id:22,name:"Bella Vita Luxury Perfume Set",brand:"Bella Vita",category:"beauty",price:599,originalPrice:999,rating:4.2,reviews:56789,image:"https://images.unsplash.com/photo-1541643600914-78b084683601?w=500&h=500&fit=crop",description:"Set of 4 (20ml each), CEO Man, Fresh, Date, Skai Aquatic. Long lasting 8-10 hours.",badge:"Gift Set",platforms:{flipkart:599,amazon:649,meesho:549}},
{id:23,name:"Yonex Mavis 350 Shuttlecock",brand:"Yonex",category:"sports",price:999,originalPrice:1390,rating:4.6,reviews:23456,image:"https://images.unsplash.com/photo-1626224583764-f87db24ac4ea?w=500&h=500&fit=crop",description:"Pack of 6, nylon, medium speed, durable, official tournament grade, consistent flight path.",badge:"",platforms:{flipkart:999,amazon:1049,meesho:1099}},
{id:24,name:"Nivia Storm Football Size 5",brand:"Nivia",category:"sports",price:599,originalPrice:999,rating:4.3,reviews:34567,image:"https://images.unsplash.com/photo-1614632537197-38a17061c2bd?w=500&h=500&fit=crop",description:"Size 5, 32 panel, machine stitched, PU material, butyl bladder, all surface, FIFA approved.",badge:"Popular",platforms:{flipkart:599,amazon:649,meesho:549}},
{id:25,name:"Boldfit Adjustable Dumbbells 10kg",brand:"Boldfit",category:"sports",price:1299,originalPrice:2499,rating:4.4,reviews:12345,image:"https://images.unsplash.com/photo-1583454110551-21f2fa2afe61?w=500&h=500&fit=crop",description:"PVC dumbbell set, 10kg total, adjustable plates, chrome rod, anti-slip grip, includes case.",badge:"48% Off",platforms:{flipkart:1299,amazon:1399,meesho:1199}},
{id:26,name:"Strauss Yoga Mat 6mm",brand:"Strauss",category:"sports",price:399,originalPrice:799,rating:4.2,reviews:56789,image:"https://images.unsplash.com/photo-1601925260368-ae2f83cf8b7f?w=500&h=500&fit=crop",description:"6mm thick, anti-skid, EVA material, carry strap, 180x60cm, sweat resistant, multipurpose.",badge:"50% Off",platforms:{flipkart:399,amazon:449,meesho:369}},
{id:27,name:"Atomic Habits by James Clear",brand:"Penguin",category:"books",price:399,originalPrice:699,rating:4.7,reviews:123456,image:"https://images.unsplash.com/photo-1544716278-ca5e3f4abd8c?w=500&h=500&fit=crop",description:"Bestselling self-help book on building good habits and breaking bad ones. Paperback, 320 pages.",badge:"#1 Best Seller",platforms:{flipkart:399,amazon:379,meesho:429}},
{id:28,name:"Rich Dad Poor Dad",brand:"Plata",category:"books",price:299,originalPrice:499,rating:4.5,reviews:98765,image:"https://images.unsplash.com/photo-1512820790803-83ca734da794?w=500&h=500&fit=crop",description:"Robert Kiyosaki's classic on financial literacy, investing, and wealth building. Paperback, 336 pages.",badge:"Trending",platforms:{flipkart:299,amazon:279,meesho:319}},
{id:29,name:"Wireless Mechanical Keyboard",brand:"Cosmic Byte",category:"electronics",price:2999,originalPrice:5999,rating:4.3,reviews:8765,image:"https://images.unsplash.com/photo-1618384887929-16ec33fab9ef?w=500&h=500&fit=crop",description:"75% layout, RGB backlit, outemu blue switches, BT 5.0 + 2.4G + USB-C, hot-swappable, PBT keycaps.",badge:"Editor's Pick",platforms:{flipkart:2999,amazon:3199,meesho:3499}},
{id:30,name:"Fastrack Analog Watch",brand:"Fastrack",category:"fashion",price:1495,originalPrice:2795,rating:4.1,reviews:43210,image:"https://images.unsplash.com/photo-1524592094714-0f0654e20314?w=500&h=500&fit=crop",description:"Analog quartz, stainless steel case, leather strap, water resistant 50m, 38mm dial, casual style.",badge:"",platforms:{flipkart:1495,amazon:1595,meesho:1395}},
{id:31,name:"Fire-Boltt Phoenix Smartwatch",brand:"Fire-Boltt",category:"electronics",price:1499,originalPrice:8999,rating:4.0,reviews:56780,image:"https://images.unsplash.com/photo-1579586337278-3befd40fd17a?w=500&h=500&fit=crop",description:"1.3\" AMOLED, BT calling, SpO2, heart rate, 120+ sports modes, IP68, 8 day battery.",badge:"83% Off",platforms:{flipkart:1499,amazon:1599,meesho:1699}},
{id:32,name:"Decathlon Running Shoes",brand:"Kalenji",category:"sports",price:1999,originalPrice:3499,rating:4.2,reviews:12345,image:"https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?w=500&h=500&fit=crop",description:"Cushion foam, breathable mesh, 240g, 6mm drop, rubber outsole, reflective details, all terrains.",badge:"",platforms:{flipkart:1999,amazon:2199,meesho:2399}},
];

/* ===== STATE ===== */
let state={
 cart:JSON.parse(localStorage.getItem('sv_cart'))||[],
 wishlist:JSON.parse(localStorage.getItem('sv_wishlist'))||[],
 userProducts:JSON.parse(localStorage.getItem('sv_userProducts'))||[],
 orders:JSON.parse(localStorage.getItem('sv_orders'))||[],
 user:JSON.parse(localStorage.getItem('sv_user'))||null,
 activeCategory:'all',
 searchQuery:'',
 filters:{platforms:['flipkart','amazon','meesho'],minPrice:0,maxPrice:100000,minRating:0,minDiscount:0,brands:[]},
 sort:'relevance',
 currentView:'shop',
 carouselIndex:0,
 aiHistory:[]
};
const save=k=>{const m={cart:'sv_cart',wishlist:'sv_wishlist',userProducts:'sv_userProducts',orders:'sv_orders',user:'sv_user'};if(m[k])localStorage.setItem(m[k],JSON.stringify(state[k]))};
const $=s=>document.querySelector(s);
const $$=s=>document.querySelectorAll(s);
const allProducts=()=>[...PRODUCTS,...state.userProducts];

/* ===== CORRECT PRICE FORMATTING ===== */
function fmt(n){
 return '\u20B9' + n.toLocaleString('en-IN');
}
function disc(o,p){
 return Math.round(((o-p)/o)*100);
}
function stars(r){
 const f=Math.floor(r);
 return '\u2605'.repeat(f)+(r%1>=.5?'\u00BD':'')+'\u2606'.repeat(5-f-(r%1>=.5?1:0));
}

/* ===== TOAST ===== */
function toast(msg,type='success'){
 const c=$('#toast-container'),t=document.createElement('div');
 t.className=`toast toast--${type}`;
 t.innerHTML=`<span class="toast__icon">${type==='success'?'\u2714':type==='error'?'\u2718':'\u2139'}</span><span>${msg}</span>`;
 c.appendChild(t);setTimeout(()=>t.remove(),2800);
}

/* ===== THEME ===== */
const themeBtn=$('#theme-toggle'),themeIcon=$('#theme-icon');
let theme=localStorage.getItem('sv_theme')||'dark';
document.documentElement.setAttribute('data-theme',theme);
themeIcon.textContent=theme==='dark'?'\uD83C\uDF19':'\u2600\uFE0F';
themeBtn.onclick=()=>{theme=theme==='dark'?'light':'dark';document.documentElement.setAttribute('data-theme',theme);themeIcon.textContent=theme==='dark'?'\uD83C\uDF19':'\u2600\uFE0F';localStorage.setItem('sv_theme',theme)};

/* ===== AUTH ===== */
const authOverlay=$('#auth-overlay');
$('#dropdown-auth-btn').onclick=()=>{if(state.user){state.user=null;save('user');updateProfile();toast('Logged out','info')}else{authOverlay.classList.add('active')}};
$('#auth-close').onclick=()=>authOverlay.classList.remove('active');
authOverlay.onclick=e=>{if(e.target===authOverlay)authOverlay.classList.remove('active')};
$$('.auth-tab').forEach(t=>t.onclick=()=>{$$('.auth-tab').forEach(x=>x.classList.remove('active'));t.classList.add('active');$('#login-form').classList.toggle('hidden',t.dataset.tab!=='login');$('#signup-form').classList.toggle('hidden',t.dataset.tab!=='signup')});
$$('.password-toggle').forEach(b=>b.onclick=()=>{const i=b.previousElementSibling;i.type=i.type==='password'?'text':'password';b.textContent=i.type==='password'?'\uD83D\uDC41':'🙈'});
$('#login-form').onsubmit=e=>{e.preventDefault();const email=$('#login-email').value;const users=JSON.parse(localStorage.getItem('sv_users'))||[];const u=users.find(x=>x.email===email);if(u&&u.password===$('#login-password').value){state.user=u;save('user');authOverlay.classList.remove('active');updateProfile();toast('Welcome back, '+u.name+'! \uD83D\uDC4B')}else if(u){toast('Wrong password','error')}else{toast('Account not found. Please sign up.','error')}};
$('#signup-form').onsubmit=e=>{e.preventDefault();const users=JSON.parse(localStorage.getItem('sv_users'))||[];const u={name:$('#signup-name').value,email:$('#signup-email').value,phone:$('#signup-phone').value,password:$('#signup-password').value};if(users.find(x=>x.email===u.email)){toast('Email already registered','error');return}users.push(u);localStorage.setItem('sv_users',JSON.stringify(users));state.user=u;save('user');authOverlay.classList.remove('active');updateProfile();toast('Welcome to ShopVerse, '+u.name+'! \uD83C\uDF89')};
function updateProfile(){
 const u=state.user;$('#profile-name').textContent=u?u.name.split(' ')[0]:'Account';
 $('#dropdown-name').textContent=u?u.name:'Guest';$('#dropdown-email').textContent=u?u.email:'Login to continue';
 $('#dropdown-auth-btn').textContent=u?'\uD83D\uDEAA Logout':'\uD83D\uDD10 Login / Sign Up';
 if(u)$('#profile-avatar').innerHTML=`<span style="font-size:16px;font-weight:700;color:var(--accent)">${u.name[0].toUpperCase()}</span>`;
}
updateProfile();

/* Profile dropdown */
let ddOpen=false;
$('#profile-btn').onclick=e=>{e.stopPropagation();ddOpen=!ddOpen;$('#profile-dropdown').classList.toggle('hidden',!ddOpen)};
document.onclick=()=>{if(ddOpen){ddOpen=false;$('#profile-dropdown').classList.add('hidden')}};

/* ===== CAROUSEL ===== */
const track=$('#carousel-track'),dots=$('#carousel-dots');
const slides=track.children.length;
for(let i=0;i<slides;i++){const d=document.createElement('div');d.className='carousel__dot'+(i===0?' active':'');d.dataset.i=i;dots.appendChild(d)}
function goSlide(i){state.carouselIndex=((i%slides)+slides)%slides;track.style.transform=`translateX(-${state.carouselIndex*100}%)`;$$('.carousel__dot').forEach((d,j)=>d.classList.toggle('active',j===state.carouselIndex))}
$('#carousel-prev').onclick=()=>goSlide(state.carouselIndex-1);
$('#carousel-next').onclick=()=>goSlide(state.carouselIndex+1);
dots.onclick=e=>{if(e.target.dataset.i)goSlide(+e.target.dataset.i)};
setInterval(()=>goSlide(state.carouselIndex+1),5000);
$$('.slide__cta').forEach(b=>b.onclick=()=>{state.activeCategory=b.dataset.category;syncCategoryPills();renderProducts()});

/* ===== CATEGORIES ===== */
function syncCategoryPills(){$$('.category-pill').forEach(p=>p.classList.toggle('active',p.dataset.cat===state.activeCategory))}
$('#categories-section').onclick=e=>{const p=e.target.closest('.category-pill');if(!p)return;state.activeCategory=p.dataset.cat;syncCategoryPills();renderProducts();showView('shop')};

/* ===== FILTERS ===== */
// Brand filter dynamic
function populateBrands(){
 const brands=[...new Set(allProducts().map(p=>p.brand))].sort();
 $('#filter-brand').innerHTML=brands.map(b=>`<label class="filter-checkbox"><input type="checkbox" value="${b}" checked> ${b}</label>`).join('');
}
populateBrands();

// Filter toggle
$$('.filter-group__title').forEach(t=>t.onclick=()=>{t.classList.toggle('collapsed');t.nextElementSibling.classList.toggle('collapsed')});

// Price sliders
const pMin=$('#price-min-slider'),pMax=$('#price-max-slider');
pMin.oninput=()=>{state.filters.minPrice=+pMin.value;$('#price-min-label').textContent=fmt(+pMin.value);renderProducts()};
pMax.oninput=()=>{state.filters.maxPrice=+pMax.value;$('#price-max-label').textContent=fmt(+pMax.value);renderProducts()};

// Rating / discount radios
$('#filter-rating').onchange=e=>{if(e.target.name==='rating'){state.filters.minRating=+e.target.value;renderProducts()}};
$('#filter-discount').onchange=e=>{if(e.target.name==='discount'){state.filters.minDiscount=+e.target.value;renderProducts()}};

// Platform checkboxes
$('#filter-platform').onchange=()=>{state.filters.platforms=[...$$('#filter-platform input:checked')].map(c=>c.value);renderProducts()};

// Brand checkboxes
$('#filter-brand').onchange=()=>{state.filters.brands=[...$$('#filter-brand input:checked')].map(c=>c.value);renderProducts()};

// Clear filters
$('#clear-filters').onclick=$('#reset-filters-btn').onclick=()=>{
 state.filters={platforms:['flipkart','amazon','meesho'],minPrice:0,maxPrice:100000,minRating:0,minDiscount:0,brands:[]};
 state.searchQuery='';$('#search-input').value='';pMin.value=0;pMax.value=100000;
 $('#price-min-label').textContent=fmt(0);$('#price-max-label').textContent=fmt(100000);
 $$('#filter-rating input').forEach(r=>r.checked=r.value==='0');
 $$('#filter-discount input').forEach(r=>r.checked=r.value==='0');
 $$('#filter-platform input,#filter-brand input').forEach(c=>c.checked=true);
 populateBrands();renderProducts();
};

// Mobile filter
$('#mobile-filter-toggle').onclick=()=>{$('#filters-sidebar').classList.toggle('mobile-open')};

// Sort
$('#sort-select').onchange=e=>{state.sort=e.target.value;renderProducts()};

/* ===== SEARCH ===== */
let searchTimer;
$('#search-input').oninput=e=>{
 clearTimeout(searchTimer);
 const q=e.target.value.trim();
 searchTimer=setTimeout(()=>{state.searchQuery=q;renderProducts();showSuggestions(q)},250);
};
$('#search-btn').onclick=()=>{state.searchQuery=$('#search-input').value.trim();renderProducts();$('#search-suggestions').classList.add('hidden')};
$('#search-category').onchange=e=>{if(e.target.value!=='all'){state.activeCategory=e.target.value;syncCategoryPills()}else{state.activeCategory='all';syncCategoryPills()}renderProducts()};
function showSuggestions(q){
 const sg=$('#search-suggestions');if(!q){sg.classList.add('hidden');return}
 const matches=allProducts().filter(p=>p.name.toLowerCase().includes(q.toLowerCase())||p.brand.toLowerCase().includes(q.toLowerCase())).slice(0,6);
 if(!matches.length){sg.classList.add('hidden');return}
 sg.innerHTML=matches.map(p=>`<div class="suggestion-item" data-id="${p.id}"><img src="${p.image}" style="width:36px;height:36px;border-radius:6px;object-fit:cover">${p.name.replace(new RegExp('('+q.replace(/[.*+?^${}()|[\]\\]/g, '\\$&')+')','gi'),'<mark>$1</mark>')}</div>`).join('');
 sg.classList.remove('hidden');
 sg.onclick=e=>{const it=e.target.closest('.suggestion-item');if(it){openQuickView(+it.dataset.id);sg.classList.add('hidden');$('#search-input').value=''}};
}
document.addEventListener('click',e=>{if(!e.target.closest('#search-wrapper'))$('#search-suggestions').classList.add('hidden')});

/* ===== RENDER PRODUCTS ===== */
function getFiltered(){
 const sc=$('#search-category').value;
 return allProducts().filter(p=>{
  const catOk=state.activeCategory==='all'||p.category===state.activeCategory;
  const scOk=sc==='all'||p.category===sc;
  const searchOk=!state.searchQuery||p.name.toLowerCase().includes(state.searchQuery.toLowerCase())||p.brand.toLowerCase().includes(state.searchQuery.toLowerCase())||p.category.includes(state.searchQuery.toLowerCase());
  const priceOk=p.price>=state.filters.minPrice&&p.price<=state.filters.maxPrice;
  const ratingOk=p.rating>=state.filters.minRating;
  const discOk=p.originalPrice?disc(p.originalPrice,p.price)>=state.filters.minDiscount:state.filters.minDiscount===0;
  const brandOk=state.filters.brands.length===0||state.filters.brands.includes(p.brand);
  return catOk&&scOk&&searchOk&&priceOk&&ratingOk&&discOk&&brandOk;
 });
}
function sortProducts(list){
 const s=state.sort;
 if(s==='price-low')return[...list].sort((a,b)=>a.price-b.price);
 if(s==='price-high')return[...list].sort((a,b)=>b.price-a.price);
 if(s==='rating')return[...list].sort((a,b)=>b.rating-a.rating);
 if(s==='discount')return[...list].sort((a,b)=>(b.originalPrice?disc(b.originalPrice,b.price):0)-(a.originalPrice?disc(a.originalPrice,a.price):0));
 if(s==='newest')return[...list].sort((a,b)=>b.id-a.id);
 return list;
}
function renderProducts(){
 const filtered=sortProducts(getFiltered());
 $('#product-count').textContent=`Showing ${filtered.length} product${filtered.length!==1?'s':''}`;
 const grid=$('#product-grid'),empty=$('#empty-state');
 if(!filtered.length){grid.innerHTML='';empty.classList.remove('hidden');return}
 empty.classList.add('hidden');
 grid.innerHTML=filtered.map((p,i)=>{
  const d=p.originalPrice?disc(p.originalPrice,p.price):0;
  const inWish=state.wishlist.includes(p.id);
  const platKeys=p.platforms?Object.keys(p.platforms):[];
  const lowestPlatform = p.platforms ? Object.entries(p.platforms).sort((a,b)=>a[1]-b[1])[0] : null;
  return`<article class="product-card" data-id="${p.id}" style="animation-delay:${Math.min(i*.04,.6)}s">
   <div class="product-card__img-wrap">
    <img src="${p.image}" alt="${p.name}" class="product-card__img" loading="lazy">
    ${p.badge?`<span class="product-card__badge">${p.badge}</span>`:''}
    <div class="product-card__actions">
     <button class="card-action-btn ${inWish?'active':''}" data-wish="${p.id}" title="${inWish?'Remove from Wishlist':'Add to Wishlist'}">${inWish?'\u2764\uFE0F':'\uD83E\uDD0D'}</button>
     <button class="card-action-btn" data-qv="${p.id}" title="Quick View">\uD83D\uDC41</button>
    </div>
    <div class="product-card__platforms">${platKeys.map(k=>`<span class="platform-tag platform-tag--${k}">${k[0].toUpperCase()+k.slice(1,2)}</span>`).join('')}</div>
   </div>
   <div class="product-card__body">
    <p class="product-card__brand">${p.brand}</p>
    <h3 class="product-card__name">${p.name}</h3>
    <div class="product-card__rating"><span class="rating-num">${p.rating} \u2605</span><span class="rating-count">(${p.reviews.toLocaleString()})</span></div>
    <div class="product-card__pricing"><span class="card-price">${fmt(p.price)}</span>${p.originalPrice?`<span class="card-original">${fmt(p.originalPrice)}</span><span class="card-discount">${d}% off</span>`:''}</div>
    ${lowestPlatform ? `<div class="product-card__best-price"><span class="best-price-label">Lowest on</span> <span class="best-price-platform best-price-platform--${lowestPlatform[0]}">${lowestPlatform[0].charAt(0).toUpperCase()+lowestPlatform[0].slice(1)}</span> <span class="best-price-value">${fmt(lowestPlatform[1])}</span></div>` : ''}
    <div class="product-card__footer"><button class="card-cart-btn" data-cart="${p.id}">\uD83D\uDED2 Add to Cart</button><button class="card-compare-btn" data-cmp="${p.id}" title="Compare prices across platforms">\u2696\uFE0F</button></div>
   </div>
  </article>`}).join('');
 // events
 grid.querySelectorAll('[data-cart]').forEach(b=>b.onclick=e=>{e.stopPropagation();addToCart(+b.dataset.cart)});
 grid.querySelectorAll('[data-wish]').forEach(b=>b.onclick=e=>{e.stopPropagation();toggleWishlist(+b.dataset.wish)});
 grid.querySelectorAll('[data-qv]').forEach(b=>b.onclick=e=>{e.stopPropagation();openQuickView(+b.dataset.qv)});
 grid.querySelectorAll('[data-cmp]').forEach(b=>b.onclick=e=>{e.stopPropagation();openCompare(+b.dataset.cmp)});
 grid.querySelectorAll('.product-card').forEach(c=>c.onclick=()=>openQuickView(+c.dataset.id));
}

/* ===== CART ===== */
function addToCart(id,qty=1){
 const ex=state.cart.find(x=>x.id===id);
 if(ex)ex.qty=Math.min(ex.qty+qty,10);else state.cart.push({id,qty});
 save('cart');updateBadges();renderCart();toast('Added to cart! \uD83D\uDED2');
}
function removeCart(id){state.cart=state.cart.filter(x=>x.id!==id);save('cart');updateBadges();renderCart();toast('Removed from cart','info')}
function updateCartQty(id,d){const it=state.cart.find(x=>x.id===id);if(!it)return;it.qty=Math.max(1,Math.min(10,it.qty+d));save('cart');updateBadges();renderCart()}
function cartSubtotal(){return state.cart.reduce((s,it)=>{const p=allProducts().find(x=>x.id===it.id);return p?s+p.price*it.qty:s},0)}
function renderCart(){
 const items=$('#cart-items'),empty=$('#cart-empty'),footer=$('#cart-footer');
 if(!state.cart.length){items.innerHTML='';empty.classList.remove('hidden');footer.style.display='none';return}
 empty.classList.add('hidden');footer.style.display='block';
 items.innerHTML=state.cart.map(it=>{const p=allProducts().find(x=>x.id===it.id);if(!p)return'';return`
  <div class="cart-item"><img src="${p.image}" alt="${p.name}" class="cart-item__img"><div class="cart-item__info"><p class="cart-item__name">${p.name}</p><p class="cart-item__price">${fmt(p.price)} x ${it.qty} = ${fmt(p.price*it.qty)}</p><div class="cart-item__controls"><button class="cart-qty-btn" data-cq="${it.id}" data-d="-1">\u2212</button><span class="cart-qty">${it.qty}</span><button class="cart-qty-btn" data-cq="${it.id}" data-d="1">+</button></div></div><button class="cart-item__remove" data-cr="${it.id}">\u2715</button></div>`}).join('');
 const sub=cartSubtotal(),gst=Math.round(sub*.18),total=sub+gst;
 $('#cart-subtotal').textContent=fmt(sub);$('#cart-gst').textContent=fmt(gst);$('#cart-total').textContent=fmt(total);
 items.querySelectorAll('[data-cq]').forEach(b=>b.onclick=()=>updateCartQty(+b.dataset.cq,+b.dataset.d));
 items.querySelectorAll('[data-cr]').forEach(b=>b.onclick=()=>removeCart(+b.dataset.cr));
}
// Cart drawer
$('#cart-toggle').onclick=()=>{$('#cart-drawer').classList.add('active');$('#cart-overlay').classList.add('active');document.body.style.overflow='hidden'};
function closeCart(){$('#cart-drawer').classList.remove('active');$('#cart-overlay').classList.remove('active');document.body.style.overflow=''}
$('#cart-close').onclick=$('#cart-overlay').onclick=closeCart;
$('#cart-shop-btn').onclick=()=>{closeCart();showView('shop')};

/* ===== CHECKOUT ===== */
$('#checkout-btn').onclick=()=>{
 if(!state.cart.length){toast('Cart is empty!','error');return}
 closeCart();
 const sub=cartSubtotal(),gst=Math.round(sub*.18),total=sub+gst;
 const itemsCount = state.cart.reduce((s,x)=>s+x.qty,0);
 $('#checkout-summary').innerHTML=`
  <div class="checkout-items-summary"><strong>${itemsCount} item${itemsCount>1?'s':''}</strong> in your order</div>
  <div class="cart-summary__row"><span>Subtotal</span><span>${fmt(sub)}</span></div>
  <div class="cart-summary__row"><span>GST (18%)</span><span>${fmt(gst)}</span></div>
  <div class="cart-summary__row"><span>Delivery</span><span class="free-tag">FREE</span></div>
  <div class="cart-summary__row cart-summary__total"><span>Total</span><span>${fmt(total)}</span></div>`;
 // Pre-fill user info if logged in
 if(state.user){
  if(state.user.name) $('#co-name').value = state.user.name;
  if(state.user.email) $('#co-email').value = state.user.email;
  if(state.user.phone) $('#co-phone').value = state.user.phone;
 }
 $('#checkout-modal').classList.add('active');
};
$('#checkout-close').onclick=$('#checkout-cancel').onclick=()=>$('#checkout-modal').classList.remove('active');
$('#checkout-form').onsubmit=e=>{e.preventDefault();const oid='SV-'+Date.now().toString(36).toUpperCase();state.orders.push({id:oid,items:[...state.cart],total:cartSubtotal()+Math.round(cartSubtotal()*.18),date:new Date().toISOString()});save('orders');state.cart=[];save('cart');updateBadges();renderCart();$('#checkout-form-view').classList.add('hidden');$('#checkout-success').classList.remove('hidden');$('#order-id').textContent=oid;toast('Order placed! \uD83C\uDF89')};
$('#order-done').onclick=()=>{$('#checkout-modal').classList.remove('active');$('#checkout-form-view').classList.remove('hidden');$('#checkout-success').classList.add('hidden');showView('shop')};

/* ===== WISHLIST ===== */
function toggleWishlist(id){
 const i=state.wishlist.indexOf(id);
 if(i>-1){state.wishlist.splice(i,1);toast('Removed from wishlist','info')}
 else{state.wishlist.push(id);toast('Added to wishlist \u2764\uFE0F')}
 save('wishlist');updateBadges();renderProducts();renderWishlist();
}
function renderWishlist(){
 const grid=$('#wishlist-grid'),empty=$('#wishlist-empty');
 $('#wishlist-page-count').textContent=`(${state.wishlist.length})`;
 if(!state.wishlist.length){grid.innerHTML='';empty.classList.remove('hidden');return}
 empty.classList.add('hidden');
 grid.innerHTML=state.wishlist.map(id=>{const p=allProducts().find(x=>x.id===id);if(!p)return'';
  const d=p.originalPrice?disc(p.originalPrice,p.price):0;
  return`
  <div class="wishlist-card"><img src="${p.image}" alt="${p.name}" class="wishlist-card__img"><div class="wishlist-card__body"><p class="wishlist-card__name">${p.name}</p><p class="wishlist-card__price">${fmt(p.price)} ${p.originalPrice?`<span class="card-original">${fmt(p.originalPrice)}</span> <span class="card-discount">${d}% off</span>`:''}</p><div class="wishlist-card__actions"><button class="wishlist-move-btn" data-wm="${p.id}">\uD83D\uDED2 Move to Cart</button><button class="wishlist-remove-btn" data-wr="${p.id}">\u2715 Remove</button></div></div></div>`}).join('');
 grid.querySelectorAll('[data-wm]').forEach(b=>b.onclick=()=>{addToCart(+b.dataset.wm);toggleWishlist(+b.dataset.wm)});
 grid.querySelectorAll('[data-wr]').forEach(b=>b.onclick=()=>toggleWishlist(+b.dataset.wr));
}
$('#wishlist-toggle').onclick=()=>showView('wishlist');
$('#wishlist-back').onclick=$('#wishlist-shop-btn').onclick=()=>showView('shop');
$('#dropdown-wishlist').onclick=e=>{e.preventDefault();showView('wishlist')};

/* ===== VIEW MANAGER ===== */
function showView(v){
 state.currentView=v;
 $('#hero-carousel').classList.toggle('hidden',v!=='shop');
 $('#categories-section').classList.toggle('hidden',v!=='shop');
 $('#content').classList.toggle('hidden',v!=='shop');
 $('#wishlist-page').classList.toggle('hidden',v!=='wishlist');
 $('#seller-page').classList.toggle('hidden',v!=='seller');
 if(v==='wishlist')renderWishlist();
 if(v==='shop')renderProducts();
 window.scrollTo({top:0,behavior:'smooth'});
}

/* ===== SELLER ===== */
$('#dropdown-sell').onclick=e=>{e.preventDefault();showView('seller')};
$('#seller-back').onclick=()=>showView('shop');
$('#seller-form').onsubmit=e=>{e.preventDefault();
 const np={id:Date.now(),name:$('#sp-name').value,brand:$('#sp-brand').value,category:$('#sp-category').value,price:+$('#sp-price').value,originalPrice:+$('#sp-original').value||null,rating:4.0,reviews:0,image:$('#sp-image').value,description:$('#sp-desc').value,badge:'New',platforms:{flipkart:+$('#sp-price').value,amazon:Math.round(+$('#sp-price').value*1.05),meesho:Math.round(+$('#sp-price').value*1.1)}};
 state.userProducts.push(np);save('userProducts');populateBrands();toast('Product published! \uD83C\uDF89');$('#seller-form').reset();showView('shop');
};

/* ===== BADGES ===== */
function updateBadges(){
 const cc=state.cart.reduce((s,x)=>s+x.qty,0);
 $('#cart-badge').textContent=cc;$('#cart-badge').classList.toggle('visible',cc>0);
 $('#wishlist-badge').textContent=state.wishlist.length;$('#wishlist-badge').classList.toggle('visible',state.wishlist.length>0);
}

/* ===== QUICK VIEW ===== */
let qvProduct=null;
function openQuickView(id){
 const p=allProducts().find(x=>x.id===id);if(!p)return;qvProduct=p;
 $('#qv-image').src=p.image;$('#qv-image').alt=p.name;$('#qv-badge').textContent=p.badge||'';$('#qv-badge').style.display=p.badge?'':'none';
 $('#qv-brand').textContent=p.brand;$('#qv-title').textContent=p.name;
 $('#qv-rating').innerHTML=`<span class="rating-num">${p.rating} \u2605</span><span class="rating-count">${p.rating} (${p.reviews.toLocaleString()} reviews)</span>`;
 $('#qv-price').textContent=fmt(p.price);$('#qv-original').textContent=p.originalPrice?fmt(p.originalPrice):'';
 const d=p.originalPrice?disc(p.originalPrice,p.price):0;$('#qv-discount').textContent=d?d+'% off':'';$('#qv-discount').style.display=d?'':'none';
 $('#qv-description').textContent=p.description;$('#qv-qty').value=1;
 const inW=state.wishlist.includes(p.id);$('#qv-wishlist').textContent=inW?'\u2764\uFE0F':'\u2661';$('#qv-wishlist').classList.toggle('active',inW);
 // platform badges
 if(p.platforms){
  const entries=Object.entries(p.platforms);
  const minP=Math.min(...entries.map(e=>e[1]));
  $('#qv-platforms').innerHTML=entries.map(([k,v])=>`<span class="platform-tag platform-tag--${k}" style="font-size:12px;padding:4px 10px">${k.charAt(0).toUpperCase()+k.slice(1)}: ${fmt(v)} ${v===minP?'\u2705':''}</span>`).join('');
 }
 $('#quickview-modal').classList.add('active');document.body.style.overflow='hidden';
}
$('#qv-close').onclick=()=>{$('#quickview-modal').classList.remove('active');document.body.style.overflow=''};
$('#quickview-modal').onclick=e=>{if(e.target.id==='quickview-modal'){$('#quickview-modal').classList.remove('active');document.body.style.overflow=''}};
$('#qv-qty-minus').onclick=()=>{const v=+$('#qv-qty').value;if(v>1)$('#qv-qty').value=v-1};
$('#qv-qty-plus').onclick=()=>{const v=+$('#qv-qty').value;if(v<10)$('#qv-qty').value=v+1};
$('#qv-add-cart').onclick=()=>{if(qvProduct){addToCart(qvProduct.id,+$('#qv-qty').value||1);$('#quickview-modal').classList.remove('active');document.body.style.overflow=''}};
$('#qv-wishlist').onclick=()=>{if(qvProduct){toggleWishlist(qvProduct.id);const inW=state.wishlist.includes(qvProduct.id);$('#qv-wishlist').textContent=inW?'\u2764\uFE0F':'\u2661';$('#qv-wishlist').classList.toggle('active',inW)}};
$('#qv-compare').onclick=()=>{if(qvProduct)openCompare(qvProduct.id)};

/* ===== PRICE COMPARE ===== */
function openCompare(id){
 const p=allProducts().find(x=>x.id===id);if(!p||!p.platforms)return;
 $('#compare-product-name').textContent=p.name;
 const entries=Object.entries(p.platforms);const minP=Math.min(...entries.map(e=>e[1]));
 const colors={flipkart:'var(--flipkart)',amazon:'var(--amazon)',meesho:'var(--meesho)'};
 $('#compare-cards').innerHTML=entries.map(([k,v])=>`
  <div class="compare-card ${v===minP?'cheapest':''}">
   <p class="compare-card__platform" style="color:${colors[k]}">${k.charAt(0).toUpperCase()+k.slice(1)}</p>
   <p class="compare-card__price">${fmt(v)}</p>
   <p class="compare-card__savings">${v>minP?fmt(v-minP)+' more':'Best price! \u2705'}</p>
   <a class="compare-card__link" href="#">Visit Store \u2192</a>
  </div>`).join('');
 const cheapest=entries.find(e=>e[1]===minP);
 const maxPrice = Math.max(...entries.map(e=>e[1]));
 $('#compare-tip').textContent=`\uD83D\uDCA1 Best deal: Buy from ${cheapest[0].charAt(0).toUpperCase()+cheapest[0].slice(1)} and save up to ${fmt(maxPrice-minP)}!`;
 $('#quickview-modal').classList.remove('active');$('#compare-modal').classList.add('active');
}
$('#compare-close').onclick=()=>$('#compare-modal').classList.remove('active');
$('#compare-modal').onclick=e=>{if(e.target.id==='compare-modal')$('#compare-modal').classList.remove('active')};

/* ===== AI ASSISTANT ===== */
const aiFab=$('#ai-fab'),aiPanel=$('#ai-panel'),aiMsgs=$('#ai-messages'),aiInput=$('#ai-input');
aiFab.onclick=()=>{aiPanel.classList.toggle('hidden');aiFab.style.display=aiPanel.classList.contains('hidden')?'':'none'};
$('#ai-close').onclick=()=>{aiPanel.classList.add('hidden');aiFab.style.display=''};
$$('.ai-suggestion').forEach(b=>b.onclick=()=>sendAI(b.dataset.q));
$('#ai-send').onclick=()=>{const q=aiInput.value.trim();if(q){sendAI(q);aiInput.value=''}};
aiInput.onkeydown=e=>{if(e.key==='Enter'){e.preventDefault();$('#ai-send').click()}};
function sendAI(q){
 // user msg
 aiMsgs.innerHTML+=`<div class="ai-msg ai-msg--user"><div class="ai-msg__avatar">\uD83D\uDC64</div><div class="ai-msg__text">${q}</div></div>`;
 // typing
 const typing=document.createElement('div');typing.className='ai-msg ai-msg--bot';typing.innerHTML='<div class="ai-msg__avatar">\uD83E\uDD16</div><div class="ai-typing"><span></span><span></span><span></span></div>';
 aiMsgs.appendChild(typing);aiMsgs.scrollTop=aiMsgs.scrollHeight;
 setTimeout(()=>{typing.remove();const reply=getAIReply(q);aiMsgs.innerHTML+=`<div class="ai-msg ai-msg--bot"><div class="ai-msg__avatar">\uD83E\uDD16</div><div class="ai-msg__text">${reply}</div></div>`;aiMsgs.scrollTop=aiMsgs.scrollHeight},1200);
}
function getAIReply(q){
 const ql=q.toLowerCase();const ap=allProducts();
 if(ql.includes('deal')||ql.includes('best')||ql.includes('offer')){
  const deals=ap.filter(p=>p.originalPrice&&disc(p.originalPrice,p.price)>=30).sort((a,b)=>disc(b.originalPrice,b.price)-disc(a.originalPrice,a.price)).slice(0,3);
  return`\uD83D\uDD25 <b>Top deals today:</b><br>`+deals.map(p=>`\u2022 <b>${p.name}</b> \u2014 ${fmt(p.price)} <span style="color:var(--success)">(${disc(p.originalPrice,p.price)}% off)</span>`).join('<br>');
 }
 if(ql.includes('compare')||ql.includes('price')){
  const kw=ql.replace(/compare|price|prices|of|the|for/gi,'').trim();const match=ap.find(p=>p.name.toLowerCase().includes(kw)||p.brand.toLowerCase().includes(kw));
  if(match&&match.platforms){const entries=Object.entries(match.platforms);return`\u2696\uFE0F <b>${match.name}</b> prices:<br>`+entries.map(([k,v])=>`\u2022 ${k.charAt(0).toUpperCase()+k.slice(1)}: <b>${fmt(v)}</b>`).join('<br>')+'<br><br>\uD83D\uDCA1 Click the \u2696\uFE0F button on any product to compare!';}
  return'\u2696\uFE0F I can compare prices! Try: "Compare boAt headphones" or click the \u2696\uFE0F button on any product card.';
 }
 if(ql.includes('recommend')||ql.includes('suggest')||ql.includes('phone')||ql.includes('laptop')||ql.includes('under')){
  const budget=parseInt(ql.match(/\d+/)?.[0])||20000;const cat=ql.includes('phone')||ql.includes('mobile')?'electronics':ql.includes('laptop')?'electronics':ql.includes('shoe')?'fashion':'';
  const recs=ap.filter(p=>p.price<=budget&&(!cat||p.category===cat)&&p.rating>=4).sort((a,b)=>b.rating-a.rating).slice(0,3);
  if(recs.length)return`\uD83D\uDCF1 <b>Recommendations under ${fmt(budget)}:</b><br>`+recs.map(p=>`\u2022 <b>${p.name}</b> \u2014 ${fmt(p.price)} (${p.rating}\u2605)`).join('<br>');
  return`I couldn't find exact matches under ${fmt(budget)}. Try adjusting your budget!`;
 }
 if(ql.includes('trending')||ql.includes('popular')||ql.includes('fashion')){
  const trending=ap.filter(p=>p.category==='fashion'||p.badge==='Trending').slice(0,3);
  return`\uD83D\uDC57 <b>Trending now:</b><br>`+trending.map(p=>`\u2022 <b>${p.name}</b> by ${p.brand} \u2014 ${fmt(p.price)}`).join('<br>');
 }
 if(ql.includes('cart')){return`\uD83D\uDED2 You have <b>${state.cart.length} items</b> in your cart totaling <b>${fmt(cartSubtotal())}</b>. Click the cart icon to view!`}
 if(ql.includes('hello')||ql.includes('hi')||ql.includes('hey')){return`Hey there! \uD83D\uDC4B I can help you with:<br>\u2022 \uD83D\uDD25 Finding best deals<br>\u2022 \u2696\uFE0F Comparing prices<br>\u2022 \uD83D\uDCF1 Product recommendations<br>\u2022 \uD83D\uDC57 What's trending<br><br>What are you looking for?`}
 return`I can help you find products, compare prices, and get the best deals! Try asking:<br>\u2022 "Best deals today"<br>\u2022 "Compare headphone prices"<br>\u2022 "Suggest a phone under 15000"<br>\u2022 "What's trending in fashion?"`;
}

/* ===== SCROLL ===== */
const scrollBtn=$('#scroll-top');
window.addEventListener('scroll',()=>{
 $('.header').classList.toggle('scrolled',scrollY>20);
 scrollBtn.classList.toggle('visible',scrollY>400);
},{passive:true});
scrollBtn.onclick=()=>window.scrollTo({top:0,behavior:'smooth'});

/* ===== KEYBOARD ===== */
document.addEventListener('keydown',e=>{
 if(e.key==='Escape'){$('#quickview-modal').classList.remove('active');$('#compare-modal').classList.remove('active');$('#checkout-modal').classList.remove('active');authOverlay.classList.remove('active');closeCart();document.body.style.overflow=''}
 if(e.key==='/'&&document.activeElement.tagName!=='INPUT'&&document.activeElement.tagName!=='TEXTAREA'){e.preventDefault();$('#search-input').focus()}
});

/* Orders page */
$('#dropdown-orders').onclick=e=>{e.preventDefault();if(!state.orders.length){toast('No orders yet','info');return}let msg='\uD83D\uDCE6 Your Orders:\n\n';state.orders.slice(-5).reverse().forEach(o=>{msg+=`${o.id} \u2014 ${fmt(o.total)} \u2014 ${new Date(o.date).toLocaleDateString()}\n`});alert(msg)};

/* ===== INIT ===== */
renderProducts();updateBadges();renderCart();
})();
