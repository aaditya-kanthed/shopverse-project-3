const express = require('express');
const Database = require('better-sqlite3');
const bcrypt = require('bcryptjs');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static(path.join(__dirname)));

// ===== DATABASE SETUP =====
const db = new Database(path.join(__dirname, 'shopverse.db'));
db.pragma('journal_mode = WAL');
db.pragma('foreign_keys = ON');

// Create tables
db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    phone TEXT DEFAULT '',
    password_hash TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  );

  CREATE TABLE IF NOT EXISTS cart (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    qty INTEGER DEFAULT 1,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE(user_id, product_id)
  );

  CREATE TABLE IF NOT EXISTS wishlist (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    product_id INTEGER NOT NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    UNIQUE(user_id, product_id)
  );

  CREATE TABLE IF NOT EXISTS orders (
    id TEXT PRIMARY KEY,
    user_id INTEGER NOT NULL,
    items_json TEXT NOT NULL,
    total REAL NOT NULL,
    status TEXT DEFAULT 'confirmed',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );

  CREATE TABLE IF NOT EXISTS user_products (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    user_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    brand TEXT NOT NULL,
    category TEXT NOT NULL,
    price REAL NOT NULL,
    original_price REAL,
    image TEXT NOT NULL,
    description TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE
  );
`);

// Prepared statements for performance
const stmts = {
  // Users
  createUser: db.prepare('INSERT INTO users (name, email, phone, password_hash) VALUES (?, ?, ?, ?)'),
  getUserByEmail: db.prepare('SELECT * FROM users WHERE email = ?'),
  getUserById: db.prepare('SELECT id, name, email, phone, created_at FROM users WHERE id = ?'),

  // Cart
  getCart: db.prepare('SELECT product_id, qty FROM cart WHERE user_id = ?'),
  upsertCart: db.prepare('INSERT INTO cart (user_id, product_id, qty) VALUES (?, ?, ?) ON CONFLICT(user_id, product_id) DO UPDATE SET qty = ?'),
  updateCartQty: db.prepare('UPDATE cart SET qty = ? WHERE user_id = ? AND product_id = ?'),
  removeFromCart: db.prepare('DELETE FROM cart WHERE user_id = ? AND product_id = ?'),
  clearCart: db.prepare('DELETE FROM cart WHERE user_id = ?'),

  // Wishlist
  getWishlist: db.prepare('SELECT product_id FROM wishlist WHERE user_id = ?'),
  addToWishlist: db.prepare('INSERT OR IGNORE INTO wishlist (user_id, product_id) VALUES (?, ?)'),
  removeFromWishlist: db.prepare('DELETE FROM wishlist WHERE user_id = ? AND product_id = ?'),

  // Orders
  createOrder: db.prepare('INSERT INTO orders (id, user_id, items_json, total) VALUES (?, ?, ?, ?)'),
  getOrders: db.prepare('SELECT * FROM orders WHERE user_id = ? ORDER BY created_at DESC'),

  // User Products
  addProduct: db.prepare('INSERT INTO user_products (user_id, name, brand, category, price, original_price, image, description) VALUES (?, ?, ?, ?, ?, ?, ?, ?)'),
  getUserProducts: db.prepare('SELECT * FROM user_products ORDER BY created_at DESC'),
};

// ===== AUTH ROUTES =====

// Sign Up
app.post('/api/auth/signup', (req, res) => {
  try {
    const { name, email, phone, password } = req.body;
    if (!name || !email || !password) {
      return res.status(400).json({ error: 'Name, email and password are required' });
    }
    if (password.length < 6) {
      return res.status(400).json({ error: 'Password must be at least 6 characters' });
    }
    const existing = stmts.getUserByEmail.get(email);
    if (existing) {
      return res.status(409).json({ error: 'Email already registered' });
    }
    const password_hash = bcrypt.hashSync(password, 10);
    const result = stmts.createUser.run(name, email, phone || '', password_hash);
    const user = stmts.getUserById.get(result.lastInsertRowid);
    res.status(201).json({ success: true, user });
  } catch (err) {
    console.error('Signup error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Login
app.post('/api/auth/login', (req, res) => {
  try {
    const { email, password } = req.body;
    if (!email || !password) {
      return res.status(400).json({ error: 'Email and password are required' });
    }
    const user = stmts.getUserByEmail.get(email);
    if (!user) {
      return res.status(404).json({ error: 'Account not found. Please sign up.' });
    }
    if (!bcrypt.compareSync(password, user.password_hash)) {
      return res.status(401).json({ error: 'Wrong password' });
    }
    const safeUser = stmts.getUserById.get(user.id);
    res.json({ success: true, user: safeUser });
  } catch (err) {
    console.error('Login error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

// Get user profile
app.get('/api/user/:id', (req, res) => {
  try {
    const user = stmts.getUserById.get(req.params.id);
    if (!user) return res.status(404).json({ error: 'User not found' });
    res.json(user);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ===== CART ROUTES =====

app.get('/api/cart/:userId', (req, res) => {
  try {
    const items = stmts.getCart.all(req.params.userId);
    res.json(items);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/cart/:userId', (req, res) => {
  try {
    const { productId, qty } = req.body;
    const userId = req.params.userId;
    const existing = stmts.getCart.all(userId).find(i => i.product_id === productId);
    const newQty = existing ? Math.min(existing.qty + (qty || 1), 10) : (qty || 1);
    stmts.upsertCart.run(userId, productId, newQty, newQty);
    const cart = stmts.getCart.all(userId);
    res.json({ success: true, cart });
  } catch (err) {
    console.error('Cart add error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

app.put('/api/cart/:userId', (req, res) => {
  try {
    const { productId, qty } = req.body;
    if (qty < 1 || qty > 10) return res.status(400).json({ error: 'Qty must be 1-10' });
    stmts.updateCartQty.run(qty, req.params.userId, productId);
    const cart = stmts.getCart.all(req.params.userId);
    res.json({ success: true, cart });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/cart/:userId/:productId', (req, res) => {
  try {
    stmts.removeFromCart.run(req.params.userId, req.params.productId);
    const cart = stmts.getCart.all(req.params.userId);
    res.json({ success: true, cart });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/cart/:userId', (req, res) => {
  try {
    stmts.clearCart.run(req.params.userId);
    res.json({ success: true, cart: [] });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ===== WISHLIST ROUTES =====

app.get('/api/wishlist/:userId', (req, res) => {
  try {
    const items = stmts.getWishlist.all(req.params.userId);
    res.json(items.map(i => i.product_id));
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.post('/api/wishlist/:userId', (req, res) => {
  try {
    stmts.addToWishlist.run(req.params.userId, req.body.productId);
    const items = stmts.getWishlist.all(req.params.userId);
    res.json({ success: true, wishlist: items.map(i => i.product_id) });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

app.delete('/api/wishlist/:userId/:productId', (req, res) => {
  try {
    stmts.removeFromWishlist.run(req.params.userId, req.params.productId);
    const items = stmts.getWishlist.all(req.params.userId);
    res.json({ success: true, wishlist: items.map(i => i.product_id) });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ===== ORDER ROUTES =====

app.post('/api/orders', (req, res) => {
  try {
    const { userId, items, total } = req.body;
    const orderId = 'SV-' + Date.now().toString(36).toUpperCase();
    stmts.createOrder.run(orderId, userId, JSON.stringify(items), total);
    stmts.clearCart.run(userId);
    res.status(201).json({ success: true, orderId });
  } catch (err) {
    console.error('Order error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/orders/:userId', (req, res) => {
  try {
    const orders = stmts.getOrders.all(req.params.userId);
    res.json(orders.map(o => ({ ...o, items: JSON.parse(o.items_json) })));
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ===== USER PRODUCTS ROUTES =====

app.post('/api/products', (req, res) => {
  try {
    const { userId, name, brand, category, price, originalPrice, image, description } = req.body;
    const result = stmts.addProduct.run(userId, name, brand, category, price, originalPrice || null, image, description);
    res.status(201).json({ success: true, productId: result.lastInsertRowid });
  } catch (err) {
    console.error('Add product error:', err);
    res.status(500).json({ error: 'Server error' });
  }
});

app.get('/api/products/user', (req, res) => {
  try {
    const products = stmts.getUserProducts.all();
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// ===== STATS ROUTE =====
app.get('/api/stats', (req, res) => {
  try {
    const userCount = db.prepare('SELECT COUNT(*) as count FROM users').get().count;
    const orderCount = db.prepare('SELECT COUNT(*) as count FROM orders').get().count;
    const productCount = db.prepare('SELECT COUNT(*) as count FROM user_products').get().count;
    res.json({ users: userCount, orders: orderCount, products: productCount });
  } catch (err) {
    res.status(500).json({ error: 'Server error' });
  }
});

// Fallback — serve index.html for any unmatched route
app.get('*', (req, res) => {
  res.sendFile(path.join(__dirname, 'index.html'));
});

// Start server
app.listen(PORT, () => {
  console.log(`\n  \x1b[35m◈ ShopVerse\x1b[0m Server running!`);
  console.log(`  \x1b[36m→\x1b[0m http://localhost:${PORT}\n`);
  console.log(`  \x1b[33mDatabase:\x1b[0m shopverse.db (SQLite)`);
  console.log(`  \x1b[32mStatus:\x1b[0m Ready to accept connections\n`);
});

// Graceful shutdown
process.on('SIGINT', () => {
  db.close();
  console.log('\n  Database closed. Goodbye!\n');
  process.exit(0);
});
